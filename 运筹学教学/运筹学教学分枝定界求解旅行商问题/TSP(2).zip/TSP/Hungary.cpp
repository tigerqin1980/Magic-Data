#include <stdio.h>
#include <cstdlib>

typedef struct matrix
{
	int cost[101][101];
	int zeroelem[101][101];
 	int costforout[101][101];
 	int matrixsize;
}MATRIX;
MATRIX hungary;
int result[5041][2];								//���������Ľ��,��һ�б�ʾ���˵ڶ��б�ʾ���� 
void zeroout(MATRIX &hungary);						//��ȥ���е���Сֵ�õ���Ԫ�� 
void circlezero(MATRIX &hungary);					//Ȧ����������Ԫ�� 
void twozero(MATRIX &hungary);						//Ȧ�����д����������ϵ���Ԫ�� 
void judge(MATRIX &hungary,int result[2000][2]);	//�ж��Ƿ�����������㷨���� 
void refresh(MATRIX &hungary);						//�������������Ծ�����б��� 
void output(int result[2000][2],MATRIX hungary);	//������ 
MATRIX input();	//��ʼ���� 			
FILE *fp;					
int main(int argc, char *argv[])
{
	freopen(argv[1], "r", stdin);
	fp = fopen(argv[2], "w");
//	freopen("input.txt", "r", stdin);
//	fp = fopen("output.txt", "w");
	result[0][0]=0;
	hungary=input();
	zeroout(hungary);
	circlezero(hungary); 
	output(result,hungary);
	fclose(stdin);
}
MATRIX input()
{
	int i,j; 
	matrix hungary;
	printf("ָ��������������ⷨ\n");
	printf("������cost����Ľ���:\n");
	scanf("%d",&hungary.matrixsize);
	printf("������������˺͹�����%d�׾���:\n",hungary.matrixsize);
	for(i=1;i<=hungary.matrixsize;i++)
  		for(j=1;j<=hungary.matrixsize;j++)
  		{   
 			scanf("%d",&hungary.cost[i][j]);
 			hungary.costforout[i][j]=hungary.cost[i][j];
  		}

 	return hungary;
}
void zeroout(MATRIX &hungary)
{
	int i,j; 
	int tem;	//��ʾͬ�е����Ԫ�ػ�ͬ�е����Ԫ�� 
	for(i=1;i<=hungary.matrixsize;i++)             //��ȥͬ�����Ԫ��
 	{ 
  	 	tem=hungary.cost[i][1];
  	 	for(j=2;j<=hungary.matrixsize;j++)
    	if(hungary.cost[i][j]<tem)
    		tem=hungary.cost[i][j];
  		for(j=1;j<=hungary.matrixsize;j++)
   		hungary.cost[i][j]=hungary.cost[i][j]-tem;
 	}
 	for(j=1;j<=hungary.matrixsize;j++)            //��ȥͬ�����Ԫ��
 	{
  		tem=hungary.cost[1][j];
  		for(i=2;i<=hungary.matrixsize;i++)
     	if(hungary.cost[i][j]<tem)
    		tem=hungary.cost[i][j];
  		for(i=1;i<=hungary.matrixsize;i++)
  			hungary.cost[i][j]=hungary.cost[i][j]-tem;
 	}
}
void circlezero(MATRIX &hungary)
{
	int i,j,p;  
	int flag; 
 	for(i=0;i<=hungary.matrixsize;i++)                         //�ھ������湹����Ȧ������0�ĸ�����
  		hungary.cost[i][0]=0; 
 	for(j=1;j<=hungary.matrixsize;j++)
  		hungary.cost[0][j]=0;
 	for(i=1;i<=hungary.matrixsize;i++)
  		for(j=1;j<=hungary.matrixsize;j++)
   		if(hungary.cost[i][j]==0)
   		{
    		hungary.cost[i][0]++;
    		hungary.cost[0][j]++;
    		hungary.cost[0][0]++;
   		} 
 	for(i=0;i<=hungary.matrixsize;i++)               //�½�һ������
  		for(j=0;j<=hungary.matrixsize;j++)           
   			hungary.zeroelem[i][j]=0;   
 	flag=hungary.cost[0][0]+1;                         //flag = 0���ܸ���+1
	while(hungary.cost[0][0]<flag)                   
	{
  		flag=hungary.cost[0][0];                                       //���е�0�������
  		for(i=1;i<=hungary.matrixsize;i++)                             //��һ�����к���
	 	{
   			if(hungary.cost[i][0]==1) 
			{
				for(j=1;j<=hungary.matrixsize;j++)                        
     			if(hungary.cost[i][j]==0&&hungary.zeroelem[i][j]==0)
      				break;
    			hungary.zeroelem[i][j]=1;
    			hungary.cost[i][0]--;
   		 		hungary.cost[0][j]--;
    			hungary.cost[0][0]--;
    			if(hungary.cost[0][j]>0)
     			for(p=1;p<=hungary.matrixsize;p++)
      			if(hungary.cost[p][j]==0&&hungary.zeroelem[p][j]==0)
      			{
       				hungary.zeroelem[p][j]=2;
       				hungary.cost[p][0]--;
       				hungary.cost[0][j]--;
       				hungary.cost[0][0]--;
      			}      
			}                           
	
  		}
		for(j=1;j<=hungary.matrixsize;j++)                            //   �ڶ������к���
 		{
   			if(hungary.cost[0][j]==1)
			{
		    	for(i=1;i<=hungary.matrixsize;i++)
     			if(hungary.cost[i][j]==0&&hungary.zeroelem[i][j]==0)
      				break;
    			hungary.zeroelem[i][j]=1;
    			hungary.cost[i][0]--;
    			hungary.cost[0][j]--;
    			hungary.cost[0][0]--;
    			if(hungary.cost[i][0]>0)
     			for(p=1;p<=hungary.matrixsize;p++)
      			if(hungary.cost[i][p]==0&&hungary.zeroelem[i][p]==0)
      			{
       				hungary.zeroelem[i][p]=2;
       				hungary.cost[i][0]--;
       				hungary.cost[0][p]--;
       				hungary.cost[0][0]--;
      			}
			}
  		}
	}
	if(hungary.cost[0][0]>0)
		twozero(hungary);
	else
		judge(hungary,result);
}
void judge(MATRIX &hungary,int result[5041][2])
{
	int i,j;
 	int num=0;	//�ߵ����� 
 	int start;	//ÿ���Ĵ��濪ʼλ�� 
 	for(i=1;i<=hungary.matrixsize;i++)
  		for(j=1;j<=hungary.matrixsize;j++)
   		if(hungary.zeroelem[i][j]==1)
    		num++;						//���ߵ����� 
		if(num==hungary.matrixsize)
		{
  			start=result[0][0]*hungary.matrixsize+1;
   			for(i=1;i<=hungary.matrixsize;i++)
    			for(j=1;j<=hungary.matrixsize;j++)
     				if(hungary.zeroelem[i][j]==1)
     				{
      					result[start][0]=i;
      					result[start++][1]=j;
     				}
   					result[0][0]++;
  		}
 		else
  			refresh(hungary);
}
void twozero(MATRIX &hungary)
{
	int i,j;
	int p,q;
	int m,n;
	int flag;
    MATRIX backup;
	for(i=1;i<=hungary.matrixsize;i++)
		if(hungary.cost[i][0]>0)
			break;
	if(i<=hungary.matrixsize)
	{
		for(j=1;j<=hungary.matrixsize;j++)
		{
			backup=hungary;//������Ѱ�Ҷ�� 
			if(hungary.cost[i][j]==0&&hungary.zeroelem[i][j]==0)
			{
    			hungary.zeroelem[i][j]=1;
    			hungary.cost[i][0]--;
    			hungary.cost[0][j]--;
    			hungary.cost[0][0]--;
    			for(q=1;q<=hungary.matrixsize;q++)
     				if(hungary.cost[i][q]==0&&hungary.zeroelem[i][q]==0)
     				{
      					hungary.zeroelem[i][q]=2;
      					hungary.cost[i][0]--;
      					hungary.cost[0][q]--;
      					hungary.cost[0][0]--;
     				}
    			for(p=1;p<=hungary.matrixsize;p++)
     				if(hungary.cost[p][j]==0&&hungary.zeroelem[p][j]==0)
     				{
      					hungary.zeroelem[p][j]=2;
      					hungary.cost[p][0]--;
      					hungary.cost[0][j]--;
      					hungary.cost[0][0]--;
     				}
    			flag=hungary.cost[0][0]+1;
    			while(hungary.cost[0][0]<flag)
    			{
     				flag=hungary.cost[0][0];
     				for(p=i+1;p<=hungary.matrixsize;p++)
     				{
     			 		if(hungary.cost[p][0]==1)
						{
       						for(q=1;q<=hungary.matrixsize;q++)
        						if(hungary.cost[p][q]==0&&hungary.zeroelem[p][q]==0)
         							break;
       							hungary.zeroelem[p][q]=1;
       							hungary.cost[p][0]--;
       							hungary.cost[0][q]--;
       							hungary.cost[0][0]--;
       						for(m=1;m<=hungary.matrixsize;m++)
        						if(hungary.cost[m][q]==0&&hungary.zeroelem[m][q]==0)
        						{
        			 				hungary.zeroelem[m][q]=2;
         							hungary.cost[m][0]--;
         							hungary.cost[0][q]--;
         							hungary.cost[0][0]--;
        						}
      					}
     				}
     				for(q=1;q<=hungary.matrixsize;q++)
     				{
      					if(hungary.cost[0][q]==1)
						{
       						for(p=1;p<=hungary.matrixsize;p++)
        						if(hungary.cost[p][q]==0&&hungary.zeroelem[p][q]==0)
         							break;
       							hungary.zeroelem[p][q]=1;
       							hungary.cost[p][q]--;
       							hungary.cost[0][q]--;
       							hungary.cost[0][0]--;
       						for(n=1;n<=hungary.matrixsize;n++)
        						if(hungary.cost[p][n]==0&&hungary.zeroelem[p][n]==0)
								{
         							hungary.zeroelem[p][n]=2;
         							hungary.cost[p][0]--;
         							hungary.cost[0][n]--;
         							hungary.cost[0][0]--;
        						}
      					}
     				}
    			}
    			if(hungary.cost[0][0]>0)                   //ȷ��hungary.cost[][]�е�0Ԫ�ض���zeroelem[][]�б���ȫ��ǳ�����
     				twozero(hungary);
    			else 
     				judge(hungary,result);
   			}           
   			hungary=backup;
  		}
 	}
}
void refresh(MATRIX &hungary)
{
	int i,j,min=0;
	int flag1=0,flag2=0;
	for(i=1;i<=hungary.matrixsize;i++)
	{
		for(j=1;j<=hungary.matrixsize;j++)
		if(hungary.zeroelem[i][j]==1)
		{
			hungary.zeroelem[i][0]=1;         //�ж�����Ԫ��
    		break;
   		}
	}
	while(flag1==0)
	{
		flag1=1;
		for(i=1;i<=hungary.matrixsize;i++)
			if(hungary.zeroelem[i][0]==0)
			{
				hungary.zeroelem[i][0]=2;
				for(j=1;j<=hungary.matrixsize;j++)
					if(hungary.zeroelem[i][j]==2)
					{
						hungary.zeroelem[0][j]=1;
					}
   			}
		for(j=1;j<=hungary.matrixsize;j++)
		{
			if(hungary.zeroelem[0][j]==1)
			{
				hungary.zeroelem[0][j]=2;
				for(i=1;i<=hungary.matrixsize;i++)
    				if(hungary.zeroelem[i][j]==1)
					{
						hungary.zeroelem[i][0]=0;
      					flag1=0;
     				}
   			}
  		}
 	}                    //�Դ򹴵��к��б�ǳ�2 
	for(i=1;i<=hungary.matrixsize;i++)
	{
		if(hungary.zeroelem[i][0]==2)
		{
			for(j=1;j<=hungary.matrixsize;j++)
			{
    			if(hungary.zeroelem[0][j]!=2)
     				if(flag2==0)
     				{
     				 	min=hungary.cost[i][j];
      					flag2=1;
     				}
     			else
				{
      				if(hungary.cost[i][j]<min)
       					min=hungary.cost[i][j];
     			}
   			}        
  		}
 	}					//Ѱ��δ�����ǵ���Сֵ 
	for(i=1;i<=hungary.matrixsize;i++)
	{
		if(hungary.zeroelem[i][0]==2)
			for(j=1;j<=hungary.matrixsize;j++)
				hungary.cost[i][j]=hungary.cost[i][j]-min;
	}
	for(j=1;j<=hungary.matrixsize;j++)
	{
		if(hungary.zeroelem[0][j]==2)
			for(i=1;i<=hungary.matrixsize;i++)
				hungary.cost[i][j]=hungary.cost[i][j]+min;
	}                   //δ�����ߵ��м�ȥδ�����ǵ���Сֵ�������ߵ��м���δ�����ǵ���Сֵ 
	for(i=0;i<=hungary.matrixsize;i++)
		for(j=0;j<=hungary.matrixsize;j++)
			hungary.zeroelem[i][j]=0;              //������0
	circlezero(hungary); 
}
void output(int result[5041][2],MATRIX hungary)
{
	int num;	//������� 
	int minsum;	//��С�Ĺ����ɱ� 
	int i,j;
	char w;
	int start;  //ÿ����Ĵ��濪ʼλ�� 
	minsum=0;
	for(i=1;i<=hungary.matrixsize;i++)
	{
		minsum=minsum+hungary.costforout[i][result[i][1]];
	}
	printf("���Ž��Ŀ�꺯��ֵΪ%d.\n",minsum);
	num=result[0][0];
  	printf("��%d�ֽ�.\n",num);  
  	i = rand() % num + 1;
	start=(i-1)*hungary.matrixsize+1;	 
	for(j=start;j<start+hungary.matrixsize;j++)
    		fprintf(fp, "%d %d\n",result[j][0],result[j][1]);
 	fprintf(fp, "\n");
	fclose(fp);
}
