/*
	Author: Hzoi_hexing
	complier: c++11 -Ofast
	Name: TSP
*/


#include<bits/stdc++.h>
using namespace std;
const int N = 100;
const int INF = 99999;
int dis[N + 5][N + 5];// ���� 
int n;// ���ݹ�ģ 
typedef vector<pair<int, int> > pair_int;
int fa[N + 5];// fa[i]��ʾi��ǰ�� 
int low = 0, up = INF;// ���½� 
const int alg_mode = 2;// alg_mode = 1 --- hungary bound, alg_mode = 2----one-tree bound
int x[N + 5][N + 5];// ������ʾȥ����·����x[i][j] = -1��ʾ·��(i.j)�����Ա�ѡȡ 
bool checked[N + 5][N + 5];
//for hungary
bool vis[N + 5];
pair_int get_circle(){//�ҳ���· 
	pair_int ans, tmp;
	ans.clear(); tmp.clear();
	memset(vis, 0, sizeof(vis));
	for (int i = 1; i <= n; i ++){
		if (vis[i]) continue;
		tmp.clear();
		int t = i;
		while (!vis[t]){
			vis[t] = 1;
			tmp.push_back(make_pair(fa[t], t));
			t = fa[t];	
		}
		vis[t] = 1;
		if (tmp.size() < ans.size() || ans.size() == 0) ans = tmp;
	}
	return ans;
}

int calc(string file_name){//������� 
	FILE *fp = fopen(file_name.c_str(), "r");
	int u, v;
	int ans = 0;
	for (int i = 1; i <= n; i ++){
		fscanf(fp, "%d %d", &u, &v);
		ans += dis[u][v];
	}
	fclose(fp);
	return ans;
}
void branch_and_bound_hungary(pair<int, int> L, int id, int depth){//��֧���� 
	static char s[20], out_s[20], cmd[50];
	sprintf(s, "input%d%d.txt", id, depth);
	sprintf(out_s, "output%d%d.txt", id, depth);
	sprintf(cmd, "Hungary.exe %s %s", s, out_s);
	FILE *fp = fopen(s, "w");
	x[L.first][L.second] = -1;
	fprintf(fp, "%d\n", n);
	for (int i = 1; i <= n; i ++){
		fa[i] = i;
		for (int j = 1; j <= n; j ++){
			if (checked[i][j]) {
				fprintf(fp, "%d ", 0);
				continue;
			}
			if (x[i][j] < 0) fprintf(fp, "%d ", INF);
			else fprintf(fp, "%d ", dis[i][j]);
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
	system(cmd);
	int u, v, now = 0;
	FILE *fp1 = fopen(out_s, "r");
	for (int i = 1; i <= n; i ++){
		fscanf(fp, "%d %d", &u, &v);
		now += dis[u][v];
		fa[v] = u;
	}
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= n; j ++)
			if (checked[i][j]) now += dis[i][j];
	fclose(fp1);
	if (now > up) {
		x[L.first][L.second] = 0;
		return;
	}//�����Ͻ� 
	pair_int cir = get_circle();
	if (cir.size() == n){//�ҵ����н� 
		up = now;
		printf("last_ans = %d last_file_name = %s\n", up, out_s);
		x[L.first][L.second] = 0;
		return;
	}else{
		int sz = cir.size();
		for (int i = 0; i < sz; i ++){
			branch_and_bound_hungary(cir[i], id, depth + 1);
			checked[cir[i].first][cir[i].second] = 1;//ȥ���� 
		}
		for (int i = 0; i < sz; i ++)
			checked[cir[i].first][cir[i].second] = 0;
	}
	
}

// for one tree
struct Edge{
	int ff, tt, ww;// an edge from ff to tt with weight ww
}c[N * N + 5];
int tot = 0;

void add(int x, int y, int z){//�½�һ����(x,y)Ȩ��Ϊz 
	c[++ tot].ff = x;
	c[tot].tt = y;
	c[tot].ww = z; 
	return;
}


int getfa(int x){//���鼯��·��ѹ�� 
	if (fa[x] == x){
		return fa[x];// �ҵ����ڵ� 
	}else{
		fa[x] = getfa(fa[x]);// ѹ��·���������Ҹ��ڵ� 
	}
}

bool comp(const Edge &a, const Edge &b){
	return a.ww < b.ww;
}// ���عؼ������� 
bool flag = 0;
pair_int kruscal(){//Ѱ��one-tree 
	flag = 0;
	pair_int one_tree;
	int tmp = 0;
	one_tree.clear();
	for (int i = 1; i <= n; i ++)
		fa[i] = i;
	sort(c + 1, c + tot + 1, comp);//�������� 
	int cnt = 0;
	for (int i = 1; i <= tot; i ++){
		if (c[i].ff == 1 || c[i].tt == 1) continue;
		if (x[c[i].ff][c[i].tt]) continue;
		int fx = getfa(c[i].ff), fy = getfa(c[i].tt);
		if (fx != fy){
			tmp += c[i].ww;
			fa[fx] = fy;
			cnt ++;
			one_tree.push_back(make_pair(c[i].ff, c[i].tt));
		}
	}	
	if (cnt < n - 2) flag = 1;//�Ƿ���ͨ 
	int min_1 = INF, min_2 = INF;
	int id1, id2;
	bool flag1 = 0, flag2 = 0;
	for (int i = 2; i <= n; i ++){
		if (x[1][i] || x[i][1]) continue;
		if (min_1 > dis[1][i]){
			min_2 = min_1;
			min_1 = dis[1][i];
			id2 = id1; id1 = i;
			flag2 = flag1;
			flag1 = 1;
		}else{
			if (min_2 > dis[1][i]){ 
				min_2 = dis[1][i], id2 = i, flag2 = 1;
			}else{
				if (min_1 > dis[i][1]){
					min_2 = min_1;
					min_1 = dis[i][1];
					id2 = id1; id1 = i;
					flag2 = flag1;
					flag1 = 0;
				}else if (min_2 > dis[i][1]) min_2 = dis[i][1], id2 = i, flag2 = 0;
			} 
		}
	}//������������� 
	one_tree.push_back(make_pair(flag1?1:id1, flag1?id1:1));
	one_tree.push_back(make_pair(flag1?1:id2, flag2?id2:1));
	return one_tree;
} 

int calc1(pair_int deg){
	int sz = deg.size();
	int ans = 0;
	for (int i = 0; i < sz; i ++)
		ans += dis[deg[i].first][deg[i].second];
	return ans;
}//������� 

pair_int degree_c(pair_int deg){
	pair_int ans;
	ans.clear();
	int sz = deg.size();
	vector <int> degree;
	for (int i = 0; i <= n; i ++)
		degree.push_back(0);
	for (int i = 0; i < sz; i ++){
		degree[deg[i].first] ++;
		degree[deg[i].second] ++;
	}
	for (int i = 1; i <= n; i ++){
		if (degree[i] >= 3){
			for (int j = 0; j < sz; j ++){
				if (deg[j].first == i || deg[j].second == i)
					ans.push_back(deg[j]);
			}
		}
	}
	return ans;
}// �������� 

void branch_and_bound_one(pair<int, int> L, int id, int depth){
	static char out_s[50];
	sprintf(out_s, "output%d%d.txt", id, depth);
	x[L.first][L.second] = -1;
	pair_int tmp1 = kruscal();
	if (flag){
		x[L.first][L.second] = 0;
		return;
	}
	pair_int tmp = degree_c(tmp1);
	int sz = tmp.size();
	int now = calc1(tmp1);
	if (now > up) {
		x[L.first][L.second] = 0;
		return;
	}//�����Ͻ� 
	if (sz == 0){
		if (up > now) {
			up = now;
			printf("ans = %d file = %s\n", calc1(tmp1), out_s);
			FILE *fp = fopen(out_s, "w");
			for (int i = 0; i < tmp1.size(); i ++)
				fprintf(fp, "%d %d\n", tmp1[i].first, tmp1[i].second);
			fclose(fp);
		}
		x[L.first][L.second] = 0;
		return;
	}
	for (int i = 0; i < sz; i ++){
		if (checked[tmp[i].first][tmp[i].second]) continue;
		branch_and_bound_one(tmp[i], id, depth + 1);
		checked[tmp[i].first][tmp[i].second] = 1;
	}
	for (int i = 0; i < sz; i ++)
		checked[tmp[i].first][tmp[i].second] = 0;
	x[L.first][L.second] = 0;
}//��֧���� 


int main(){
	memset(checked, 0, sizeof(checked));
	FILE *fp = fopen("input.txt", "r");
	fscanf(fp, "%d", &n);
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= n; j ++)
			fscanf(fp, "%d", &dis[i][j]);
	fclose(fp);
	if (alg_mode == 1){
		system("Hungary.exe input.txt output.txt");// ����������⣬��Ϊbound 
		FILE *fp1 = fopen("output.txt", "r");
		int u, v;
		memset(x, 0, sizeof(x));
		for (int i = 1; i <= n; i ++) fa[i] = i;
		for (int i = 0; i < n; i ++){
			fscanf(fp1, "%d %d", &u, &v);
			fa[v] = u;
			low += dis[u][v];
		}		
		fclose(fp1);
		memset(vis, 0, sizeof(vis));	
		pair_int cir = get_circle();
		int sz = cir.size();
		if (sz == n){
			FILE *last = fopen("ans.txt", "w");
			printf("%d\n", low);
			return 0;
		}
		for (int i = 0; i < sz; i ++){
			memset(x, 0, sizeof(x));
			branch_and_bound_hungary(cir[i], i, 0);
			checked[cir[i].first][cir[i].second] = 1;//ȥ���� 
		}
	}else{
		memset(x, 0, sizeof(x));
		for (int i = 1; i <= n; i ++)
			for (int j = i + 1; j <= n; j ++){
				add(i, j, dis[i][j]);
			}
		pair_int deg = kruscal();
		low = calc1(deg);
		pair_int set_of_edg = degree_c(deg);
		int sz = set_of_edg.size();
		for (int i = 0; i < sz; i ++){
			memset(x, 0, sizeof(x));
			if (checked[set_of_edg[i].first][set_of_edg[i].second]) continue;
			branch_and_bound_one(set_of_edg[i], i, 0);
			checked[set_of_edg[i].first][set_of_edg[i].second] = 1;//ȥ���� 
		}
	}
	
}
